---
functions:
  shell:
    - code: |
        man man
        !/bin/sh
  file-read:
    - code: man file_to_read
  sudo:
    - code: |
        sudo man man
        !/bin/sh
---
