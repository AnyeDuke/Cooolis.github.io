---
functions:
  shell:
    - code: zsh
  suid:
    - code: ./zsh
  sudo:
    - code: sudo zsh
---
