sed -i "" "2 a\  
entitlements;
" project.pbxproj
